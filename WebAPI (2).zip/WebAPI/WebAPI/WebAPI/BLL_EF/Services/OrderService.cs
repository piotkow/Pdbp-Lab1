﻿using BLL.DTOModels;
using BLL.ServiceInterfaces;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Numerics;
using System.Text;
using System.Threading.Tasks;

namespace BLL_EF.Services
{
    public class OrderService : IOrderService
    {
        private readonly WebstoreContext _context;

        public OrderService(WebstoreContext context)
        {
            _context = context;
        }
        public IEnumerable<OrderPositionResponseDTO> GetOrderDetails(int orderID)
        {
            var order = _context.Orders
            .Include(o => o.OrderPositions)
            .ThenInclude(op => op.Product)
            .FirstOrDefault(o => o.ID == orderID);

            return order.OrderPositions.Select(op => new OrderPositionResponseDTO(op.Product.Name, op.Price, op.Amount)).ToList();
        }

        public IEnumerable<OrderResponseDTO> GetOrders(string sortBy, bool ascending, int filterID, bool filterPaid)
        {
            var query = _context.Orders
                 .Include(o => o.OrderPositions)
                 .AsQueryable();

            if (filterID > 0)
                query = query.Where(o => o.ID == filterID);

            if (filterPaid)
                query = query.Where(o => o.isPaid == true);

            query = sortBy switch
            {
                "id" => ascending ? query.OrderBy(o => o.ID) : query.OrderByDescending(o => o.ID),
                "value" => ascending ? query.OrderBy(o => CalculateOrderTotal(o.ID)) : query.OrderByDescending(o => CalculateOrderTotal(o.ID)),
                "date" => ascending ? query.OrderBy(o => o.Date) : query.OrderByDescending(o => o.Date),
                _ => query
            };

            return query.Select(o => new OrderResponseDTO(
                o.ID,
                CalculateOrderTotal(o.ID),
                o.isPaid,
                o.Date
            )).ToList();
        }

        private double CalculateOrderTotal(int orderID)
        {
            var orderPositions = _context.OrderPositions.Where(op => op.OrderID == orderID).ToList();
            return orderPositions.Sum(op => op.Price * op.Amount);
        }

        public void PayOrder(int orderID, double amount)
        {
            var order = _context.Orders.FirstOrDefault(o => o.ID == orderID);

            if (order.isPaid)
                throw new InvalidOperationException("Order has already been paid");


            var totalAmount = CalculateOrderTotal(orderID);

            if (amount != totalAmount)
                throw new InvalidOperationException("Payment amount is not enough");

            order.isPaid = true;
            _context.SaveChanges();

        }
    }
}

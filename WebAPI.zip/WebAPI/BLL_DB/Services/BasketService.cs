﻿using BLL.ServiceInterfaces;
using Dapper;
using Microsoft.EntityFrameworkCore;
using Model.Models;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BLL_DB.Services
{
    public class BasketServiceDB : IBasketService
    {

        private readonly WebstoreContext _context;

        public BasketServiceDB(WebstoreContext context)
        {
            _context = context;
        }
        public void AddToBasket(int userID, int productID, int amount)
        {
            using (var connection = _context.CreateConnection())
            {
                var parameters = new DynamicParameters();
                parameters.Add("@UserId", userID);
                parameters.Add("@ProductId", productID);
                parameters.Add("@Quantity", amount);

                connection.Execute("AddToBasket", parameters, commandType: CommandType.StoredProcedure);
            }
        }

        public int GenerateOrder(int userID)
        {
                using (var connection = _context.CreateConnection())
                {
                    var parameters = new DynamicParameters();
                    parameters.Add("UserID", userID);

                    var orderId = connection.QuerySingle<int>("GenerateOrder", parameters, commandType: CommandType.StoredProcedure);

                    return orderId;
                }
        }

        public void RemoveFromBasket(int userID, int productID)
        {
            using (var connection = _context.CreateConnection())
            {
                var parameters = new DynamicParameters();
                parameters.Add("@UserId", userID);
                parameters.Add("@ProductId", productID);

                connection.Execute("RemoveFromBasket", parameters, commandType: CommandType.StoredProcedure);
            }
        }

        public void UpdateBasketItem(int userID, int productID, int amount)
        {
            using (var connection = _context.CreateConnection())
            {
                var parameters = new DynamicParameters();
                parameters.Add("@UserId", userID);
                parameters.Add("@ProductId", productID);
                parameters.Add("@NewQuantity", amount);

                connection.Execute("UpdateBasketQuantity", parameters, commandType: CommandType.StoredProcedure);
            }
        }
    }
}

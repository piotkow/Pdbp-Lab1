﻿using BLL.DTOModels;
using BLL.ServiceInterfaces;
using Dapper;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BLL_DB.Services
{
    public class OrderServiceDB : IOrderService
    {

        private readonly WebstoreContext _context;

        public OrderServiceDB(WebstoreContext context)
        {
            _context = context;
        }

        public IEnumerable<OrderPositionResponseDTO> GetOrderDetails(int orderID)
        {
            throw new NotImplementedException();
        }

        public IEnumerable<OrderResponseDTO> GetOrders(string sortBy, bool ascending, int filterID, bool filterPaid)
        {
            throw new NotImplementedException();
        }

        public void PayOrder(int orderID, double amount)
        {
            using (var connection = _context.CreateConnection())
            {
                var parameters = new DynamicParameters();

                parameters.Add("@OrderID", orderID);
                parameters.Add("@Amount", amount);

                parameters.Add("@Success", dbType: DbType.Boolean, direction: ParameterDirection.Output);

                connection.Execute("PayOrder", parameters, commandType: CommandType.StoredProcedure);

                bool success = parameters.Get<bool>("@Success");

                if (!success)
                {
                    var order = _context.Orders.FirstOrDefault(o => o.ID == orderID);
                    if (order.isPaid)
                        throw new InvalidOperationException("Order has already been paid");

                    throw new InvalidOperationException("Payment amount is not enough");
                }
            }
        }

    }
}

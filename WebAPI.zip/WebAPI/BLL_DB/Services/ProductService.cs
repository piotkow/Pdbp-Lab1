﻿using Dapper;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using BLL;
using BLL.DTOModels;
using BLL.ServiceInterfaces;
using Model.Models;

namespace BLL_DB.Services
{
    public class ProductServiceDB : IProductService
    {
        private readonly WebstoreContext _context;

        public ProductServiceDB(WebstoreContext context)
        {
            _context = context;
        }

        public void ActivateProduct(int productID)
        {
            using (var connection = _context.CreateConnection())
            {
                var parameters = new DynamicParameters();
                parameters.Add("@ProductId", productID);

                connection.Execute("ActivateProduct", parameters, commandType: CommandType.StoredProcedure);
            }
        }

        public void AddProduct(ProductRequestDTO product)
        {
            using (var connection = _context.CreateConnection())
            {
                var parameters = new DynamicParameters();
                parameters.Add("@Name", product.Name);
                parameters.Add("@Price", product.Price);
                parameters.Add("@Image", product.Image);
                parameters.Add("@IsActive", product.IsActive);
                parameters.Add("@GroupId", product.GroupID);


                connection.Execute("AddProduct", parameters, commandType: CommandType.StoredProcedure);
            }
        }

        public void DeactivateProduct(int productID)
        {
            throw new NotImplementedException();
        }

        public void DeleteProduct(int productID)
        {
            using (var connection = _context.CreateConnection())
            {
                var parameters = new DynamicParameters();
                parameters.Add("@ProductId", productID);

                connection.Execute("DeleteProduct", parameters, commandType: CommandType.StoredProcedure);
            }
        }

        public IEnumerable<ProductResponseDTO> GetProducts(string sortBy, bool ascending, string filterName, string filterGroupName, int filterGroupID, bool includeInactive)
        {
            using (var connection = _context.CreateConnection())
            {
                var parameters = new DynamicParameters();
                parameters.Add("@SortBy", sortBy);
                parameters.Add("@Ascending", ascending);
                parameters.Add("@NameFilter", filterName);
                parameters.Add("@GroupNameFilter", filterGroupName);
                parameters.Add("@GroupId", filterGroupID);
                parameters.Add("@IncludeInactive", includeInactive);

                return connection.Query<ProductResponseDTO>("GetProducts", parameters, commandType: CommandType.StoredProcedure).ToList();
            }
        }

    }
}

﻿CREATE PROCEDURE ActivateProduct
    @ProductID INT
AS
BEGIN
    UPDATE Products SET IsActive = 1 WHERE ID = @ProductID;
END;
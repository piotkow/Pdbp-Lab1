﻿CREATE PROCEDURE AddProduct
    @Name NVARCHAR(100),
    @Price DECIMAL(10,2),
	@Image NVARCHAR(100),
	@IsActive BIT,
    @GroupID INT
AS
BEGIN
    INSERT INTO Products (Name, Price, Image, IsActive, GroupID)
    VALUES (@Name, @Price, @Image, @IsActive, @GroupID);
END;
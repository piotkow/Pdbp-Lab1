﻿CREATE PROCEDURE AddToBasket
    @UserID INT,
    @ProductID INT,
    @Quantity INT
AS
BEGIN
    IF EXISTS (SELECT 1 FROM BasketPositions WHERE UserID = @UserID AND ProductID = @ProductID)
    BEGIN
        UPDATE BasketPositions
        SET Amount = Amount + @Quantity
        WHERE UserID = @UserID AND ProductID = @ProductID;
    END
    ELSE
    BEGIN
        INSERT INTO BasketPositions (UserID, ProductID, Amount)
        VALUES (@UserID, @ProductID, @Quantity);
    END
END;
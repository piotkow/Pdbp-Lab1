﻿CREATE PROCEDURE PayOrder
    @OrderID INT,
    @Amount DECIMAL(18, 2),
    @Success BIT OUTPUT
AS
BEGIN
    DECLARE @TotalAmount DECIMAL(18, 2);
    DECLARE @OrderPaid BIT;

    SELECT @OrderPaid = isPaid FROM Orders WHERE ID = @OrderID;

    IF @OrderPaid = 1
    BEGIN
        SET @Success = 0;
        RETURN;
    END

    SELECT @TotalAmount = SUM(Price * Amount) 
    FROM OrderPositions
    WHERE OrderID = @OrderID;

    IF @Amount <> @TotalAmount
    BEGIN
        SET @Success = 0;
        RETURN;
    END

    UPDATE Orders 
    SET isPaid = 1 
    WHERE ID = @OrderID;

    SET @Success = 1;
END;

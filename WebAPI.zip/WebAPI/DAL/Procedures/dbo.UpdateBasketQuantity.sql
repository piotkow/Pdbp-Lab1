﻿CREATE PROCEDURE UpdateBasketQuantity
    @UserID INT,
    @ProductID INT,
    @NewQuantity INT
AS
BEGIN
    UPDATE BasketPositions
    SET Amount = @NewQuantity
    WHERE UserID = @UserID AND ProductID = @ProductID;
END;
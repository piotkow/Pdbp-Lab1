﻿CREATE TRIGGER trg_CleanupEmptyBaskets
ON BasketPositions
AFTER UPDATE
AS
BEGIN
    SET NOCOUNT ON;

    DELETE FROM BasketPositions
    WHERE Amount = 0;
END;